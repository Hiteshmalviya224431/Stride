# Stride – Android app

Your Stride web app wrapped as a native Android app, with your logo as the launcher icon.
Steps come from the phone's built-in hardware step counter (works in the background).

## Get the APK (easiest – no installs)

1. Create a free GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab → **Build APK** → wait ~3 minutes.
3. Open the finished run → download **Stride-apk** → unzip → `Stride.apk`.
4. Copy it to your phone, tap it, and allow "Install unknown apps" when asked.

## Or build locally (Android Studio)

1. Install Android Studio and choose **Open** → select this folder.
2. Wait for Gradle sync, then **Build → Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

Command line (needs JDK 17 + Android SDK): `./gradlew assembleDebug`

## Notes

- First launch asks for **Physical activity** permission – allow it so steps are counted.
- Don't use the in-app "Start Step Sensor" button on Android; the hardware counter already runs automatically.
- Export CSV opens the Android share sheet.
- To publish on Google Play, replace the debug signing key in `app/build.gradle` with your own keystore.
- Logo files: `branding/stride-icon-1024.png` and `branding/play-store-icon-512.png`.
