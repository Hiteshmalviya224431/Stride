package com.stride.stepcounter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Hosts the Stride web app in a WebView and feeds it the phone's hardware
 * step counter (TYPE_STEP_COUNTER) through window.onNativeStepUpdate().
 */
public class MainActivity extends Activity implements SensorEventListener {

    private static final int REQ_ACTIVITY = 42;
    private static final String PREFS = "stride_native";

    private WebView webView;
    private SensorManager sensorManager;
    private Sensor stepSensor;
    private SharedPreferences prefs;
    private boolean pageReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF07080C);
        getWindow().setNavigationBarColor(0xFF07080C);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF07080C);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        webView.addJavascriptInterface(new Bridge(), "StrideNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                pushSteps(prefs.getLong("steps", 0), prefs.getString("day", "").equals(today()));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
                final EditText input = new EditText(MainActivity.this);
                input.setText(def);
                input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(input)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm(input.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
        requestActivityPermission();
    }

    private void requestActivityPermission() {
        if (Build.VERSION.SDK_INT >= 29
                && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ_ACTIVITY);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_ACTIVITY) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                registerSensor();
            } else {
                Toast.makeText(this, "Allow Physical activity permission to count steps.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private boolean hasPermission() {
        return Build.VERSION.SDK_INT < 29
                || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    private void registerSensor() {
        if (stepSensor == null) {
            Toast.makeText(this, "This phone has no hardware step counter.", Toast.LENGTH_LONG).show();
            return;
        }
        if (hasPermission()) {
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerSensor();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        long raw = (long) event.values[0];
        String today = today();
        String savedDay = prefs.getString("day", "");
        long last = prefs.getLong("lastRaw", -1);
        long steps = prefs.getLong("steps", 0);

        if (!today.equals(savedDay)) {
            steps = 0;                                   // new day
        } else if (last >= 0) {
            steps += (raw >= last) ? (raw - last) : raw; // counter resets on reboot
        }
        prefs.edit().putString("day", today).putLong("lastRaw", raw).putLong("steps", steps).apply();
        pushSteps(steps, true);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void pushSteps(long steps, boolean valid) {
        if (!pageReady || !valid) return;
        final String js = "window.onNativeStepUpdate && window.onNativeStepUpdate(" + steps + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** Exposed to the page as window.StrideNative. */
    private class Bridge {
        @JavascriptInterface
        public void shareCsv(String filename, String csv) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/csv");
                send.putExtra(Intent.EXTRA_SUBJECT, filename);
                send.putExtra(Intent.EXTRA_TEXT, csv);
                startActivity(Intent.createChooser(send, "Export step history"));
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
